package org.home.dkg.service;

public interface LoginService {
	
	String getLoggedinUserName();

}
